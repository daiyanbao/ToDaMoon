package btc38

import "log"

func (b *BTC38) checkNewCoin() {
	log.Println("btc38.com's checkNewCoin is empty")
}
