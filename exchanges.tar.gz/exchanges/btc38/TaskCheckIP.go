package btc38

//checkIP 是因为利用API访问btc38的公网IP必须在btc38上注册过。
//有时路由器的外网IP会变化
func (b *BTC38) checkIP() {

}
