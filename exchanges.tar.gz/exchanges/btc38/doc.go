package btc38

/*
btc38模块是btc38.com的API封装
btc38.API除了含有exchanges.API的方法外，还含有btc38特有的API方法。
btc38.API.AllTicker() 返回全部货币的Ticker
btc38.API.MyTradeList() 返回我的交易记录

btc38的特殊性
1. 访问其API的IP需要事先在网站填写。

*/
