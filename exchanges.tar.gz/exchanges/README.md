# exchanges
是我对虚拟币交易所API的Go语言封装。

## 支持的交易所
1. [x] btc38.com
1. [ ] okcoin.cn